Here is the 'Yelp' Maps project.
Sorry there is no sh or bat script to help run the functions, it would take too long to write for now.

usage: recommend.pyc [-h] [-u USER] [-k K] [-q QUERY] [-p] [-r]

[-h, --help]
Outputs this:

Run Recommendations

optional arguments:
  -h, --help            show this help message and exit
  -u USER, --user USER  user file, e.g.
                        {likes_southside,one_cluster,likes_expensive}
  -k K, --k K           for k-means
  -q QUERY, --query QUERY
                        search for restaurants by category e.g.
                        {Books, Mags, Music and Video,Halal,Bakeries}
  -p, --predict         predict ratings for all restaurants
  -r, --restaurants     outputs a list of restaurant names